<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#" lang="ru-ru" dir="ltr" >
    <head>
        
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="author" content="Super User" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.5, user-scalable=no" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Главная</title>  
  <link href="/" rel="shortcut icon" type="image/vnd.microsoft.icon" />  
  
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Sans:700,regular,italic,700italic" type="text/css" />
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:regular" type="text/css" />
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Gudea:700,regular,italic" type="text/css" />
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Rokkitt:700,regular" type="text/css" />

  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/bootstrap.min.css" type="text/css" />  
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/js/touchspin/jquery.bootstrap-touchspin.css" type="text/css" />  
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/js/circliful/css/jquery.circliful.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/fonts/fontawesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/fonts/custom/css/music.css" type="text/css" />
  
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/menu-touch.css" type="text/css" media="screen and (max-width: 992px)" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/owl.carousel_1.3.3.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/template.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/responsive.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/colors/orange/style.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/update.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/chosen.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/custom.css" type="text/css" />  
  
  <?php wp_head();?> 
   
  
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com/angular.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com/owl.carousel.min_1.3.3.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/script.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/touchspin/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/masonry.pkgd.min.js" type="text/javascript"></script>
  
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.elastislide.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.hoverdir.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.stellar.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/headroom/jQuery.headroom.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/headroom/headroom.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/SmoothScroll.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/circliful/js/jquery.circliful.min.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com/bootstrap.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com/bootstrap.mootools-fix.js" type="text/javascript"></script>
  
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com_content.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/com_k2.js" type="text/javascript"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/chosen.jquery.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/style.css" type="text/css" />		

    </head>
    <div id="wrapper">
            <div id="mainsite">
				<div class="headroom headroom--pinned headroom--top" style="position: fixed;">
					<div class="block-panel-wrapper">
					<!--Block top-->
					<section id="block-panel">
						<div class="container">
							<div class="block blockequalize equal-column  row">
								<div class="col-md-3 col-sm-3">
									<div class="position position-panel-3">											
										<i class="fa fa-heart" aria-hidden="true"></i><a href="<?php echo get_permalink( get_page_by_path( 'wishlist' ) );?>"><span><?php echo __('Избранное');?></span></a>&nbsp;&nbsp;			
										<i class="fa fa-check" aria-hidden="true"></i><a href="<?php echo get_permalink( get_page_by_path( 'compare' ) );?>"><span><?php echo __('Сравнить');?></span></a>			
									</div>
								</div>
								<?php if ( has_nav_menu( 'primary' ) ) : ?>
								<div class="col-md-4 col-sm-4">
									<div class="position position-panel-1">
										<div class="jv-module module panel-shop panel-shop-1">                           				
												<?php
													// Primary navigation menu.
													wp_nav_menu( array( 
														'menu_class'     => 'menu',
														'theme_location' => 'primary',
														'link_before'    => '<span>',
														'link_after'     => '</span>',
													) );
												?>                                
											</div>                       
									</div>
								</div>
								<?php endif;?>
								<div class="col-md-5 col-sm-5">
									<div class="position position-panel-2">
										<div class="jv-module">                           
											<div class="jv-login register">
											<?php  if( !is_user_logged_in() ):?>
												<a id="btnlogin456" href="<?php echo get_permalink( get_page_by_path( 'my-account' ) );?>" data-toggle="modal" class="jv-login--link2"><?php echo __('Вход/Регистрация');?></a> <?php echo __('для получения постоянных скидок');?>
											<?php else: ?>
												<i class="fa fa-user" aria-hidden="true"></i><a id="btnlogin456" href="<?php echo get_permalink( get_page_by_path( 'my-account' ) );?>" data-toggle="modal" class="jv-login--link2"><?php echo __('Аккаунт');?></a>&nbsp;&nbsp;
												<i class="fa fa-sign-in" aria-hidden="true"></i><a id="btnlogin456" href="<?php echo wp_logout_url( home_url() ); ?>" data-toggle="modal" class="jv-login--link2"><?php echo __('Выход');?></a>
											<?php endif;?>
											</div>                           
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
					<!--/Block top-->
					<!--Block top-->
					<section id="block-panel-full-site">
						<h3 class="hidden">Venedor Panel</h3>
						<div class="position position-panel-full-site">
							<div class="jv-module  module panel-extra-info">
								<div class="container">
									<div class="contentmod clearfix">
										<div class="custom">
											<div class="clearfix">
												<ul>
													<li>
														<div class="extra-info--block">
															<div class="separator"></div>
															<span><?php echo __('Время');?><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo get_theme_mod( "_days");?></span></span> <span> Работы<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo get_theme_mod( "_time");?></span></span>
														</div>
													</li>
													<li>
														<div class="extra-info--block music-icon-1"><span><?php echo get_theme_mod( "_phone");?></span> <span> <a class="callback" data-toggle="modal" data-target="#myModal" href="javascript: void(0);">обратный звонок</a></span></div>
													</li>
													<li>
														<div class="extra-info--block"><span><i class=" glyphicon  fa fa-skype"></i>&nbsp;<a href="skype:<?php echo get_theme_mod( "_skype");?>?chat"><?php echo get_theme_mod( "_skype");?></a></span> <span><i class="glyphicon  fa fa-envelope"></i>&nbsp;<a href="mailto:<?php echo get_theme_mod( "_email");?>"><?php echo get_theme_mod( "_email");?></a></span></div>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</section>
					<!--/Block top-->
				</div>

				<!--Block Header -->
				<header id="block-header">
					<div class="container">
						<div class="position position-logo">
							<div class="jv-module module logo logo-homepage-1">
								<div class="contentmod clearfix">
									<div class="custom">
										<p><span><span><i></i><?php echo( the_custom_logo() ); ?></a></span></span></p>
									</div>
								</div>
							</div>
						</div>
						<a id="logo" class="logo-bg" href="/" title="Promate">				
						</a>
						<div class="position position-reponsive-menu">
							<div class="reponsive-menu">
								<span>Menu</span>
								<span>
								<a class="flexMenuToggle" href="JavaScript:void(0);">
								<span></span>
								<span></span>
								<span></span>
								</a>
								</span>
							</div>
						</div>
					</div>
				</header>
				
				<!--/Block Header-->
				<!--Block Mainnav-->
				<div class="block-menu-search">
					<div class="container">
						<section id="block-mainnav">            
							<div class="position position-menu">								
								<div class="jv-module module_menu menu-homepage-1">
									<div class="contentmod clearfix">
										<a href="<?php echo site_url(); ?>"><img id="logo-2" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo_icon_2.png"/></a>
										<?php											
											wp_nav_menu( array( 
												'menu_class'     => 'menu fxmenu dropmenu',
												'theme_location' => 'main',
												'link_before'    => '<span class="fx-title">',
												'link_after'     => '</span>',
											) );
										?>                              
									</div>
								</div>
							</div>
						</section>
						<section id="block-search">						
							<div class="position position-search">
								<div class="menu-jvajaxsearch">
									<div class="moduletable module--search-ajax">
										<div data-ng-app="jvAjaxSearch" class="ng-scope">
											<div data-ng-controller="jvControllerSearch" class="ng-scope">
												<div id="jv-ajaxsearchpro--527" class="jv-ajaxsearchpro">
													<form id="jvajax-search-527" class="jv-ajaxsearchpro--form ng-pristine ng-valid" action="<?php echo site_url(); ?>" method="GET" name="jv-ajaxsearch">
														<div class="jv-ajaxsearchpro--wrapper">
															<div class="jv-ajaxsearchpro--wrapper-input">																
																<input data-ng-keydown="jvKeydown()" placeholder="Искать..." data-module="527" class="jv-ajaxsearchpro--input" id="jvsearch-area527" type="text" autocomplete="off" value="" name="s">
															</div>
															<div class="jv-ajaxsearchpro--wrapper-plugin"></div>
														</div>
														<span class="jv-ajaxsearchpro--icon"><i class="fa fa-search"></i></span>
														<input type="hidden" name="post_type" value="product"/>
													</form>
												</div>
											</div>
										</div>
										<script>
											var ngAjaxSearch = angular.module('jvAjaxSearch',[]);
											ngAjaxSearch.controller('jvControllerSearch',function($scope, $http){
												var jvform = jQuery('#jv-ajaxsearchpro--527');
												var lastKeyUp = 0,lastVal = '',input = jvform.find('input.jv-ajaxsearchpro--input'),interval;
												var jrs = jQuery('#jResults527');
												
												input.keydown(function(){
														lastKeyUp = new Date().getTime();														
														
												}).focusin(function(){							
													clearInterval(interval);
													interval = setInterval(function(){
															if(( new Date().getTime() - lastKeyUp) < 1000) return;
															var val = input.val();
															if(val && val != '') val = val.trim();
															else return;
															if(val === lastVal) return;
															lastVal = val;
															
															var mid = input.attr('data-module'),
																loadding = jQuery('[id="jv-loading-'+mid+'"]'),
																url = 'index.php?option=com_jvajax_searchpro&format=raw&module_id='+input.attr('data-module')+'&search_w='+input.val()
															;
															if('') url += '&lang=';
															loadding.show();
															$http.get(url).success(function(data){
																jrs.addClass('showResults').show();
																$scope.hasAjaxResult = true;
																
																$scope.rs = data;
																$scope.jvResults = data.results || {};
																if(data.results.length < 1){
																	$scope.noResults = true;
																	$scope.hasResults = false;
																}else{
																	$scope.noResults = false;
																	$scope.hasResults = true;
																}
																loadding.hide();
																
															})
													},10);
													
												}).focusout(function(){
														clearInterval(interval);
														jQuery('#phone-04').css('display', 'inline-block');
												});
												$scope.jactive = '*'
												$scope.filterAll = function(clicked){
													$scope.jvResults = $scope.rs.results || {};
													$scope.jactive = clicked;
													
													
												}
												$scope.filterSearch = function(clicked){
													var plug = this.result.alias,
														jResults = $scope.rs.results[plug]
													;
													$scope.jvResults = {};
													$scope.jvResults[plug] = jResults;
													$scope.jactive = clicked;
													
												}
												
											})
											ngAjaxSearch.controller('jSearchResult',function(){ console.log(1); });
											
											(function($){
												$(document).ready(function(){
													$('span.jv-ajaxsearchpro--icon').click(function(){														
														
														if($('.jv-ajaxsearchpro').hasClass('active')){
															
															$('form[name="jv-ajaxsearch"]').submit();
														}else{
															jQuery('#phone-04').css('display', 'none');
														}
													});													
												});
											})(jQuery)
											
										</script>		
									</div>
								</div>
								<?php if ( is_active_sidebar( 'cart-block' ) ) : ?>
									<?php dynamic_sidebar( 'cart-block' ); ?>
								<?php endif; ?>								
							</div>
						</section>
					</div>
				</div>
			</div>
			<div class="z-index-top" style="padding-top: 225px;">
				<?php if ( is_active_sidebar( 'block-slide' ) ) : ?>
					<?php dynamic_sidebar( 'block-slide' ); ?>
				<?php endif; ?>
				<?php if(!is_front_page()):?>
				<section id="block-breadcrumb2">
					<div class="position position-breadcrumb">
						<div class="jv-module  module jv-breadcrumb">
							<div class="container">										
								<div class="contentmod clearfix">
									<div class="breadcrumb-wrapper">
										<?php
											if(is_woocommerce() && is_single()){
												woocommerce_breadcrumb();
											}else if(!is_woocommerce()){
												dimox_breadcrumbs();
											}
											
										?>
									</div>            
								</div> 
							</div>  
						</div>
					</div>
				</section>
				<?php endif;?>
				<?php if(is_front_page() || is_product()):?>
				<section id="full-site">
					<div class="position position-full-site">
						<div class="block-full-site">
						<ul class="container">
							<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/icon1.png" alt="" border="0"><span>Гарантия 12 месяцев</span></li>
							<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/icon2.png" alt="" border="0"><span>Быстрая доставка</span></li>
							<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/icon3.png" alt="" border="0"><span>Сервисное обслуживание</span></li>
							<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/icon4.png" alt="" border="0"><span>Сертификаты качества</span></li>
							</ul>
						</div>
					</div>
				</section>
				<?php endif; ?>
			</div>