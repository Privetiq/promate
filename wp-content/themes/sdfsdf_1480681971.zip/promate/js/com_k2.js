jQuery(function($) {
	$('.k2item-meta-item .dropdown-menu').on({
		"click":function(e){
	      e.stopPropagation();
	    }
	});	
});